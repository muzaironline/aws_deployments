export const REGISTER_DEVICE = "azan_alert/add_device";
export const REMOVE_DEVICE = "azan_alert/remove_device";