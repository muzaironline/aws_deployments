import { DeviceBaseDTO } from "../domain/dto/device/DeviceBaseDTO.js";
import * as deviceRepository from "../repository/device.repository.js";

export const getAllDevices = async() => {
    const devices = await deviceRepository.getAllDevices();
    let deviceList = devices.map(device => DeviceBaseDTO(device));
    return deviceList;
}

export const getDeviceById = async(mac) => {
    return await deviceRepository.getDeviceById(mac);
}

export const getDevicesByCity = async(city) => {
    const devices = await deviceRepository.getDevicesByCity(city);
    let deviceList = devices.map(device => DeviceBaseDTO(device));
    return deviceList;
}

export const addDevice = async(device) => {
    return await deviceRepository.addDevice(device);
}

export const updateDeviceById = async(device, id) => {
    return await deviceRepository.updateDeviceById(device, id);
}

export const deleteDeviceById = async(device) => {
    return await deviceRepository.deleteDeviceById(device);
}