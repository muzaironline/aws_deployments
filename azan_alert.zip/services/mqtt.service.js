import { REGISTER_DEVICE, REMOVE_DEVICE } from "../enums/mqttTopic.enums.js";
import { mqClient } from "../mqtt/client/mqttClient.js";
import { addDevice, deleteDeviceById } from "./device.service.js";

export const mqttPublish = (topic, msg) => {
    try {
        mqClient.publish(`azan_alert/${topic}`, msg)
    } catch (e) {
        console.error("mqtt EROR:: ", e);
    }
}

export const mqttSubscribe = (topic) => {
    mqClient.subscribe(topic, (err) => {
        if (!err) {
            console.log("Subscribed to the topic " + topic)
        }
    });
}

export const mqttMessageHandle = async(topic, msg) => {
    try {
        if (topic === REGISTER_DEVICE) {
            const res = await addDevice(JSON.parse(msg));
            mqttPublish(topic.substring(11) + "/std", JSON.stringify(res))
        }

        if (topic === REMOVE_DEVICE) {
            const res = await deleteDeviceById(JSON.parse(msg).MAC_Address);
            mqttPublish(topic.substring(11) + "/std", JSON.stringify(res))
        }
    } catch (err) {
        console.error("ERR in MQTT Service: ", err)
    }
}