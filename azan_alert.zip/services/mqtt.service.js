import { mqClient } from "../mqtt/client/mqttClient.js";

export const mqttPublish = (topic, msg) => {
    try {
        mqClient.publish(`azan_alert/${topic}`, msg)
    } catch (e) {
        console.error("mqtt EROR:: ", e);
    }
}

export const mqttSubscribe = (topic) => {
    mqClient.subscribe(topic, (err) => {
        if (!err) {
            console.log("Subscribed to the topic " + topic)
        }
    });
}