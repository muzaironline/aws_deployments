import cron from "node-cron";
import * as mqttService from "../services/mqtt.service.js";

export const createCronJob = (data) => {
    if (data.date && data.time && data.city) {
        const date = data.date.split('-')[2];
        const month = data.date.split('-')[1];
        const hour = data.time.split(':')[0];
        const min = data.time.split(':')[1];
        const cronTime = `${min} ${hour} ${date} ${month} *`;

        mqttService.mqttPublish("crons", JSON.stringify(data))

        cron.schedule(cronTime, async() => {
            let devices = await azanScheduleRepository.getDevicesByCity(data.city);
            devices = devices.map(device => DeviceBaseDTO(device))
            let res = {...data, devices: devices };
            console.log(" Azan Alert::::::::::::::::: ");
            console.log(res)
            for (let device of devices) {
                mqttService.mqttPublish(device, JSON.stringify(data))
            }
        }, {
            timezone: 'GMT0'
        })
    }
}