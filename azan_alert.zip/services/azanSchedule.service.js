import { AzanScheduleBaseDTO } from "../domain/dto/azanSchedule/AzanScheduleBaseDTO.js";
import { DeviceBaseDTO } from "../domain/dto/device/DeviceBaseDTO.js";
import * as azanScheduleRepository from "../repository/azanSchedule.repository.js";
import * as cronService from "./cron.service.js";

export const getAzanSchedule = async(date) => {
    let cityList = [];
    let deviceList = {};
    let dailySchedule = await azanScheduleRepository.getDailyAzanSchedule(date);
    dailySchedule = dailySchedule.map(sch => AzanScheduleBaseDTO(sch))

    for (let each of dailySchedule) {
        cityList.push(each.City);
    }

    for (let city of cityList) {
        let devices = await azanScheduleRepository.getDevicesByCity(city);
        devices = devices.map(device => DeviceBaseDTO(device))
        deviceList[city] = devices;
    };

    return {
        azanSchedule: dailySchedule,
        // cityList,
        deviceList
    }

}


export const updateCronScheduling = async() => {
    try {
        let dailySchedule = await azanScheduleRepository.getDailyAzanSchedule();
        dailySchedule = dailySchedule.map(sch => AzanScheduleBaseDTO(sch));

        for (let each of dailySchedule) {
            cronService.createCronJob({ date: each.Date, time: each.Fajr, type: 'Fajr', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Shuruq, type: 'Shuruq', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Dhuha, type: 'Dhuha', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Dhuhr, type: 'Dhuhr', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Asr, type: 'Asr', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Maghrib, type: 'Maghrib', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Isha, type: 'Isha', city: each.City });
            cronService.createCronJob({ date: each.Date, time: each.Qibla_Hour, type: 'Qibla_Hour', city: each.City });
        }
        return true;
    } catch (e) {
        console.error("Error while updating Crons ::: ", e)
    }
}