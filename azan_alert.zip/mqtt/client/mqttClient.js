import * as mqtt from "mqtt"; // import everything inside the mqtt module and give it the namespace "mqtt"
// let client = mqtt.connect("mqtt://test.mosquitto.org"); // create a client
import dotenv from "dotenv";
import { mqttMessageHandle } from "../../services/mqtt.service.js";
export let mqClient;
export let connectionStatus = false;

export const getMqttClient = () => {
    return mqClient;
}

export const connect = () => {
    dotenv.config();
    console.log("Connecting to..........", process.env.MQTT_HOST, process.env.MQTT_PORT);
    mqClient = mqtt.connect(process.env.MQTT_HOST, { port: 1883 });

    mqClient.on("connect", () => {
        connectionStatus = true;
        console.log("Connected to MQTT Server!")
        mqClient.subscribe("azan_alert/#", (err) => {
            if (!err) {
                mqClient.publish("azan_alert/info", `Hello from Node Server ${new Date()} `, (err, data) => {
                    if (err) {
                        console.error("Error MQTT::: ", err);
                    }
                });
            }
        });
    });

    mqClient.on("message", (topic, message) => {
        // message is Buffer
        console.log("MQTT msg rec:::: ", topic, message.toString());
        mqttMessageHandle(topic, message);

        // mqClient.end();
    });
}