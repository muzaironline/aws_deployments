import * as AzanScheduleService from '../services/azanSchedule.service.js';
import cron from "node-cron";

export const updateCronScheduling = async() => {
    return await AzanScheduleService.updateCronScheduling();
}

export const updateDailyAzanScheduling = () => {
    cron.schedule("0 0 2 * * *", async() => {
        console.log("updateCronScheduling @ 2AM night")
        return await updateCronScheduling();
    }, {
        timezone: 'GMT0'
    });
    console.log("Added 2AM Cron Job!")
}