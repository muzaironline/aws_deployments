import cron from "node-cron";
import * as mqttService from "../services/mqtt.service.js";

export const heartbeatCron = () => {
    cron.schedule("*/5 * * * *", async() => {
        console.log("heartbeat cron @ 5min interval")
        mqttService.mqttPublish("heartbeat/std", JSON.stringify({
            date: new Date().toISOString().split("T")[0],
            time: new Date().toISOString().split("T")[1].split(".")[0],
            type: "heartbeat",
        }))
    }, {
        timezone: 'GMT0'
    });
    console.log("Added heartbeat Cron @ 5min interval!")
}