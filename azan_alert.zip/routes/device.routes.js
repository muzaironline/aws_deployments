import express from "express";
import { getAllDevices, addDevice, getDeviceById, updateDeviceById, deleteDeviceById, getDevicesByCity } from "../controllers/device.controller.js";

const router = express.Router();

router.get("/", getAllDevices);
router.post("/", addDevice);
router.get("/:id", getDeviceById);
router.put("/:id", updateDeviceById);
router.delete("/:id", deleteDeviceById);
router.get("/city/:cityName", getDevicesByCity);


export default router;