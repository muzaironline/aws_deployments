import azanScheduleRoutes from "./azanSchedule.routes.js";
import deviceRoutes from "./device.routes.js";


const Routes = (app) => {
    app.use("/api/azan", azanScheduleRoutes)
    app.use("/api/devices", deviceRoutes)
}

export default Routes;