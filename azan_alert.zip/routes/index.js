import azanScheduleRoutes from "./azanSchedule.routes.js";

const Routes = (app) => {
    app.use("/", azanScheduleRoutes)
        // app.use("/client", clientRoutes)
}

export default Routes;