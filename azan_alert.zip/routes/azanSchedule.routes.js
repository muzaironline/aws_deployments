import express from "express";
import * as azanSchController from "../controllers/azanSchedule.controller.js";

const router = express.Router();

router.get("/schedule", azanSchController.getAzanSchedule);

export default router;