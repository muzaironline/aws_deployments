import * as fs from "fs";
import path from "path";
import { writeFileSync } from "fs";
import { sequelize } from "../repository/db.js";
import { Azan_Schedule, Azan_Schedule_Schema } from "./models/Azan_Schedule.js";
import { Device, Device_Schema } from "./models/Device.js";
import { City, City_Schema } from "./models/City.js";
import sequelizeErd from "sequelize-erd";


export let models;

export const init = async(db) => {
    let keys = [];
    const __dirname = path.resolve();

    try {
        // let files = fs.readdirSync(path.join(__dirname, "/domain/models"));

        const azanSchedule = Azan_Schedule();
        const device = Device();
        const city = City();

        Azan_Schedule_Schema.belongsTo(City_Schema, { as: "city", foreignKey: "City" });
        City_Schema.hasMany(Device_Schema, { as: "Devices", foreignKey: "City" });
        Device_Schema.belongsTo(City_Schema, { as: "city", foreignKey: "City" })

        models = {
            Azan_Schedule: Azan_Schedule_Schema,
            City: City_Schema,
            Device: Device_Schema
        }

        // const newDev = await models.Device.create({
        //     MAC_Address: "00:1B:44:11:3A:B2",
        //     Device_Name: "Dev 2",
        //     Country: "United States",
        //     Country_Code: "USA",
        //     City: "Rawalpindi"
        // });
        // console.log("device:::::: ", newDev);

        db.sequelize.sync();

        // const svg = await sequelizeErd({ source: db.sequelize }); // sequelizeErd() returns a Promise
        // writeFileSync('./erd.svg', svg);

        // const rwp = await models.City.findOne({ where: { City: "Rawalpindi" } });
        // console.log("rwp:: ", rwp);
        // const devs = await rwp.getDevices({ raw: true });
        // console.log("devs:: ", devs);


    } catch (err) {
        console.log("Error in RDBMS::: ", err);
    }
}