import { Model, DataTypes, Sequelize } from "sequelize";
// const sequelize = new Sequelize('sqlite::memory:');
import { sequelize } from "../../repository/db.js";

export const Azan_Schedule_Schema = sequelize.define('Azan_Schedule', {
    // Model attributes are defined here
    Date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Day: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    Fajr: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    Shuruq: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    Dhuha: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    Dhuhr: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    Asr: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    Maghrib: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    Isha: {
        type: DataTypes.TIME,
        allowNull: false,
    },
    Qibla_Hour: {
        type: DataTypes.TIME,
        allowNull: true,
    },
    // City: {
    //     type: DataTypes.STRING(200),
    //     allowNull: false,
    // },
    // City_Code: {
    //     type: DataTypes.STRING(10),
    //     allowNull: true,
    // },
    Country: {
        type: DataTypes.STRING(200),
        allowNull: false,
    },
    Country_Code: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },


}, {
    // Other model options go here
});

// `sequelize.define` also returns the model
console.log("Azan_Schedule :: ", Azan_Schedule_Schema === sequelize.models.Azan_Schedule); //

export function Azan_Schedule() {
    return new Azan_Schedule_Schema();
}