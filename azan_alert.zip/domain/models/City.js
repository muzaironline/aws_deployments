import { Model, DataTypes, Sequelize } from "sequelize";
// const sequelize = new Sequelize('sqlite::memory:');
import { sequelize } from "../../repository/db.js";

export const City_Schema = sequelize.define('City', {
    // Model attributes are defined here
    City: {
        type: DataTypes.STRING(200),
        primaryKey: true,
        unique: true,
        allowNull: false,
    },
    City_Code: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },


}, {
    // Other model options go here
});

// `sequelize.define` also returns the model
console.log("City :: ", City_Schema === sequelize.models.City); //

export const City = () => {
    return new City_Schema();
}