import { Model, DataTypes, Sequelize } from "sequelize";
// const sequelize = new Sequelize('sqlite::memory:');
import { sequelize } from "../../repository/db.js";

export const Device_Schema = sequelize.define('Device', {
    // Model attributes are defined here
    MAC_Address: {
        type: DataTypes.STRING(200),
        primaryKey: true,
        unique: true,
        allowNull: false,
    },
    Device_Name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    // City: {
    //     type: DataTypes.STRING(200),
    //     allowNull: false,
    // },
    // City_Code: {
    //     type: DataTypes.STRING(10),
    //     allowNull: true,
    // },
    Country: {
        type: DataTypes.STRING(200),
        allowNull: false,
    },
    Country_Code: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },


}, {
    // Other model options go here
});

// `sequelize.define` also returns the model
console.log("Device :: ", Device_Schema === sequelize.models.Device); //

export const Device = () => {
    return new Device_Schema();
}