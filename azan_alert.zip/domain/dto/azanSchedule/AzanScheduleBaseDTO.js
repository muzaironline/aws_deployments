export const AzanScheduleBaseDTO = (raw) => {
    return {
        Date: raw.Date,
        Fajr: raw.Fajr,
        Shuruq: raw.Shuruq,
        Dhuha: raw.Dhuha,
        Dhuhr: raw.Dhuhr,
        Asr: raw.Asr,
        Maghrib: raw.Maghrib,
        Qibla_Hour: raw.Qibla_Hour,
        Isha: raw.Isha,
        City: raw.City,
    };
}