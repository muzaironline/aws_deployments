export const DeviceBaseDTO = (raw) => {
    return raw.MAC_Address;
}