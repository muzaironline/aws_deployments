import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import helmet from "helmet";
import morgan from "morgan";
import * as db from "./repository/db.js";
import Routes from "./routes/index.js";
import * as modelInit from "./domain/index.js"
import * as azanCron from "./cron/azanAlert.cron.js";
import * as mqttClient from "./mqtt/client/mqttClient.js";
import { heartbeatCron } from "./cron/heartbeat.cron.js";

const initDB = async() => {
    // connect with database
    await db.connect();
    await modelInit.init(db);
}

const startApp = () => {
    // configs
    dotenv.config();
    // console.log("options: ", db.options);
    const app = express();
    app.use(express.json());
    app.use(helmet());
    app.use(helmet.crossOriginResourcePolicy({ policy: "cross-origin" }));
    app.use(morgan("common"));
    app.use(bodyParser.json())
    app.use(bodyParser.json({ type: 'application/*+json' }));
    app.use(bodyParser.urlencoded({ extended: false }));
    app.use(cors());

    try {
        initDB().then(() => {
            // add routes
            Routes(app);
            app.listen(process.env.SERVER_PORT, async() => {
                console.log(`Server Started on port : ${process.env.SERVER_PORT}`);
                mqttClient.connect();
                setTimeout(async() => {
                    await azanCron.updateCronScheduling();
                    azanCron.updateDailyAzanScheduling()
                    heartbeatCron();
                }, 3000);
            });
        })

    } catch (err) {
        console.log("Error occured while starting the App:: ", err)
    }

}

startApp();