import * as domain from '../domain/index.js';

export const getDailyAzanSchedule = async(date) => {
    try {
        let options = {
            where: { Date: date ? date : new Date().toJSON().split('T')[0] },
        };
        return await domain.models.Azan_Schedule.findAll(options);
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const getDevicesByCity = async(city) => {
    try {
        const cityObj = await domain.models.City.findOne({ where: { City: city } });
        return await cityObj.getDevices({ raw: true });
    } catch (err) {
        console.log(err);
        return err;
    }
}