import * as domain from '../domain/index.js';

export const getAllDevices = async() => {
    try {
        return await domain.models.Device.findAll();
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const getDeviceById = async(mac) => {
    try {
        const cityObj = await domain.models.Device.findOne({ where: { MAC_Address: mac } });
        return cityObj;
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const getDevicesByCity = async(city) => {
    try {
        const cityObj = await domain.models.Device.findAll({ where: { City: city } });
        return cityObj;
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const addDevice = async(device) => {
    try {
        const cityObj = await domain.models.Device.create(device);
        return cityObj;
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const updateDeviceById = async(device, mac) => {
    try {
        const cityObj = await domain.models.Device.update(device, { where: { MAC_Address: mac } });
        return cityObj;
    } catch (err) {
        console.log(err);
        return err;
    }
}

export const deleteDeviceById = async(device) => {
    try {
        await domain.models.Device.destroy({ where: { MAC_Address: device } });
        return true;
    } catch (err) {
        console.log(err);
        return err;
    }
}