// import { Sequelize } from "sequelize-typescript";
import { Sequelize } from "sequelize";
import { writeFileSync } from "fs";
// const sequelizeErd = require("sequelize-erd");
import dotenv from "dotenv";
dotenv.config();

export const options = {
    host: process.env.DB_URL,
    port: process.env.DB_PORT,
    database: process.env.DB_NAME,
    dialect: process.env.DB_DIALECT,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    logging: false,
    define: {
        freezeTableName: true,
    },
};
export const sequelize = new Sequelize(options);

export const connect = async() => {
    try {
        await sequelize.authenticate();
        return true;
    } catch (err) {
        console.log("error in db connect", err);
    }
}