import * as AzanScheduleService from "../services/azanSchedule.service.js";

export const getAzanSchedule = async(req, res) => {
    const data = await AzanScheduleService.getAzanSchedule();
    res.status(200).send(data);
}