import * as deviceService from "../services/device.service.js"

export const getAllDevices = async(req, res) => {
    const data = await deviceService.getAllDevices();
    res.status(200).send(data);
}

export const getDeviceById = async(req, res) => {
    const data = await deviceService.getDeviceById(req.params.id);
    res.status(200).send(data);
}

export const getDevicesByCity = async(req, res) => {
    const data = await deviceService.getDevicesByCity(req.params.cityName);
    res.status(200).send(data);
}

export const addDevice = async(req, res) => {
    const data = await deviceService.addDevice(req.body);
    res.status(200).send(data);
}

export const updateDeviceById = async(req, res) => {
    const data = await deviceService.updateDeviceById(req.body, req.params.id);
    res.status(201).send(data);
}

export const deleteDeviceById = async(req, res) => {
    await deviceService.deleteDeviceById(req.params.id);
    res.status(201).send(true);
}